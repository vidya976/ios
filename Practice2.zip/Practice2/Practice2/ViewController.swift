//
//  ViewController.swift
//  Practice2
//
//  Created by Nalluri,Srividya on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputtextOutlet: UITextField!
    
    
    @IBOutlet weak var OutputLabelOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonClicked(_ sender: Any) {
        var inputtext = InputtextOutlet.text!
        if(inputtext.contains("a") || inputtext.contains("A")) {            OutputLabelOutlet.text! = "The \(inputtext) contains a vowel😀"        }
        else if(inputtext.contains("e") || inputtext.contains("E")){
            OutputLabelOutlet.text! = "The \(inputtext) contains a vowel😀"        }
        else if(inputtext.contains("i") || inputtext.contains("I")){
            OutputLabelOutlet.text! = "The \(inputtext) contains a vowel😀"        }
        else if(inputtext.contains("o") || inputtext.contains("O")){
            OutputLabelOutlet.text! = "The \(inputtext) contains a vowel😀"        }
        else if(inputtext.contains("u") || inputtext.contains("U")){
            OutputLabelOutlet.text! = "The \(inputtext) contains a vowel😀"        }
        else{
            OutputLabelOutlet.text! = "The \(inputtext) has no vowel😔"        }
    }
    
}

