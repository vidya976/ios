//
//  ViewController.swift
//  discount
//
//  Created by Nalluri,Srividya on 2/14/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AmountOutlet: UITextField!
    
    @IBOutlet weak var RateOutlet: UITextField!
    
    @IBOutlet weak var DisplayLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonClicked(_ sender: Any) {
        var amount = Double(AmountOutlet.text!)!
        var rate = Double(RateOutlet.text!)!
        var result:Double = amount-(amount*rate/100)
        DisplayLabelOutlet.text = "Price after discount : $\(result)"
    }
    
}

