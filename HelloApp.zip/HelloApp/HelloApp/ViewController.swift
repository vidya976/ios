//
//  ViewController.swift
//  HelloApp
//
//  Created by Nalluri,Srividya on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputNameOutlet: UITextField!
    
    @IBOutlet weak var InputLastNameOutlet: UITextField!
    
    @IBOutlet weak var DisplayLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func ButtonClicked(_ sender: UIButton) {
        //read thhe input name and store it
        //assign it to a variable
        var input = InputNameOutlet.text!
        
        var lnameinput = InputLastNameOutlet.text!
        
        //perform string interpolation(Hello, John!)and assign it to the display label
        DisplayLabelOutlet.text = "Hello, \(input) \(lnameinput)!"
        
    }
    
}

