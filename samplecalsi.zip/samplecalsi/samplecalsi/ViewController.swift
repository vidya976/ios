//
//  ViewController.swift
//  samplecalsi
//
//  Created by Nalluri,Srividya on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabelOutlet: UILabel!
    
    var operand1 = -1.1
    var caloperator = " "
    var operand2 = -1.1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Btn5clicked(_ sender: Any) {
        //Display 5
        DisplayLabelOutlet.text = DisplayLabelOutlet.text! + "5"
        if(operand1 == -1.1)
        {
            operand1=5
        }
        else{
            operand2=5
        }
    }
    
    @IBAction func Btnplusclicked(_ sender: Any) {
        DisplayLabelOutlet.text = DisplayLabelOutlet.text! + "+"
        if(caloperator == " "){
            caloperator = "+"
        }
    }
    
    @IBAction func Btn4clicked(_ sender: Any) {
        DisplayLabelOutlet.text = DisplayLabelOutlet.text! + "4"
        if(operand2 == -1.1)
        {
            operand2=4
        }
        else{
            operand1=4
        }
    }
    
    @IBAction func Btneqclicked(_ sender: Any) {
        DisplayLabelOutlet.text = DisplayLabelOutlet.text! + "="
        if(caloperator == "+"){
            DisplayLabelOutlet.text = DisplayLabelOutlet.text! + "\(operand1 + operand2)"
        }
    }
}

