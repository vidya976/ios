//
//  ViewController.swift
//  Nalluri_Exam03
//
//  Created by Nalluri,Srividya on 4/27/23.
//

import UIKit

class Movie{
    var movieName : String?
    var movieImage : String?
    
    init(moviename:String,movieimage:String){
        self.movieName = moviename
        self.movieImage = movieimage
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movieArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViewOutlet.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = movieArray[indexPath.row].movieName
        
        return cell
    }
    

    @IBOutlet weak var TableViewOutlet: UITableView!
    
    var movieArray = [Movie]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TableViewOutlet.delegate = self
        TableViewOutlet.dataSource = self
        
        let m1 = Movie(moviename: "Dasara", movieimage: "dasara")
        movieArray.append(m1)
        
        let m2 = Movie(moviename: "Ante Sundaraniki", movieimage: "AS")
        movieArray.append(m2)
        
        let m3 = Movie(moviename: "Gang Leader", movieimage: "gl")
        movieArray.append(m3)
        
        let m4 = Movie(moviename: "V", movieimage: "v")
        movieArray.append(m4)
        
        let m5 = Movie(moviename: "Jersey", movieimage: "jersey")
        movieArray.append(m5)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultDescription"{
            let destination = segue.destination as! ResultViewController
            destination.movie = movieArray[(TableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }
}

