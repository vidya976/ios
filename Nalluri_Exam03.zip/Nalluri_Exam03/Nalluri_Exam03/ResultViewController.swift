//
//  ResultViewController.swift
//  Nalluri_Exam03
//
//  Created by Nalluri,Srividya on 4/27/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var labelViewOL: UILabel!
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    var movie : Movie?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageViewOL.image = UIImage(named: (movie?.movieImage)!)
        labelViewOL.text = movie?.movieName
    }
    
    @IBAction func AnimateBTNclicked(_ sender: Any) {
       
        var mov = (movie?.movieImage)!
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.alpha = 0
            
        })
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.alpha=1
            self.imageViewOL.image = UIImage(named: mov)
        })
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
