//
//  ViewController.swift
//  CourseReg
//
//  Created by Nalluri,Srividya on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var Course1inputOutlet: UITextField!
    
    @IBOutlet weak var Course2InputOutlet: UITextField!
    
    @IBOutlet weak var displayLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    @IBAction func SubmitButtonClicked(_ sender: UIButton) {
        //Read Course1 from crs1Outlet and store it in a variable.
        var crs1Name = Course1inputOutlet.text!
        //Read Course2 from crs1Outlet and store it in a variable.
        var crs2Name = Course2InputOutlet.text!
        // Performing string interpolation and assign it to display label
        displayLabelOutlet.text = "\(crs1Name) - \(crs2Name)"
    }
    
    
}

